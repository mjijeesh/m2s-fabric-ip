
Fabric IP M3 Processor Demo for Smartfusion2
-------------------------------------------

Target Hardware : M2S-CREATIVE-BRD

Core Used		 : Soft IP Cores
Libero    	 : Libero Soc v2022.1
Softconsole 	 : v2021.3



Regular peripherals of CoreUART, CoreTimer(2), CoreGPIo(2).

Two SPI Ip used, one for SPI Flash on baord and another for SD card via MikroBus connector

50Mhz Clock from Board external Crystal via the MSS PLL.


Systick and Timer examples provide with Ext_Interrupt and the MEI_Interupt(0).



22nd May 2023
