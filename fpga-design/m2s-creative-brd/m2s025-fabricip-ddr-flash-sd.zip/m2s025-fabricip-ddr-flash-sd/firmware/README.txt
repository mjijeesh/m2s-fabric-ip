Export Firmware README

Microsemi Corporation - Microsemi Libero Software Release v2022.1 (Version 2022.1.0.10)

Date    :    Tue May 23 14:41:31 2023
Project :    C:\Users\jijeesh\workspace\cortex-m3\m3-fabric-ip\fpga-designs\m3_m2s025_fabricip_ddr_flash_sdcard_v20221p1
